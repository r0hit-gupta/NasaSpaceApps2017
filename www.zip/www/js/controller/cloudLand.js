app.controller('CloudLandCtrl', function($scope, $window) {
    if ($window.ga) {
        $window.ga.trackView('What is that?');
    }
});
